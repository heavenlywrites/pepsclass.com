# pepsclass.com

The coming-soon version of pepsclass.com. Accounts, the planner and payments launch in 2027.

## Publish on GitHub Pages
1. Upload everything in this zip to the top level of your repo (not inside a folder).
2. Settings → Pages → Build and deployment → Deploy from a branch → `main`, `/ (root)` → Save.
3. The `CNAME` file already sets the domain to pepsclass.com. At your domain registrar, point pepsclass.com to GitHub Pages (GitHub shows the DNS records under Settings → Pages), then tick **Enforce HTTPS** once it's available.

`.nojekyll` tells GitHub to serve the files exactly as they are.

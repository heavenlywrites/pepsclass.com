// coming-soon version: no logins or payments yet. The Pepsclass logo in the top right opens a small note.
window.PCS = (function () {
  function esc(s) { return String(s || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
  function header() {
    const el = document.getElementById('acct'); if (!el) return;
    el.innerHTML = `<button type="button" class="pfp" aria-haspopup="true" aria-expanded="false" aria-label="Accounts coming soon"><img src="img/logo.png" alt=""></button>
      <div class="menu" role="menu"><div class="who">Accounts and the planner are coming soon 2027 ♡</div></div>`;
    const b = el.querySelector('button'), m = el.querySelector('.menu');
    b.onclick = (e) => { e.stopPropagation(); const on = !m.classList.contains('on'); m.classList.toggle('on', on); b.setAttribute('aria-expanded', on); };
    document.addEventListener('click', (e) => { if (!el.contains(e.target)) m.classList.remove('on'); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') m.classList.remove('on'); });
  }
  document.addEventListener('DOMContentLoaded', header);
  return { esc, header };
})();
